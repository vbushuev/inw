#ifndef _CANDLE_STRUCTS_H_
#define _CANDLE_STRUCTS_H_
typedef struct {
	uchar v1;
	uchar v2;
	uchar v3;
	uchar v4;
	uchar v5;
	uchar v6;
	uchar v7;
	uchar v8;
	uchar v9;
	uchar v10;
	uchar v11;
	uchar v12;
	uchar v13;
	uchar v14;
	uchar v15;
	uchar v16;
} sDO,*psDo;
#endif
