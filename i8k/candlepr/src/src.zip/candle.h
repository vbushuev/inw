#ifndef _CANDLE_H_
#define _CANDLE_H_

int doCommand(sStep sstep);
//int doScenario(sStep *currentScenario, int steps, int circles);
//Hobot V1-A1

#endif
